<h1>Тестовое задание</h1>
<h2>Задача</h2>
<p>Написать REST-сервис, выполняющий CRUD операции над таблицей products и один метод, который возвращает сумму полей <i><strong>amount</strong></i>
по полю <i><strong>name</strong></i></p>

<h2>Пререквизиты</h2>
<p>Должен быть запущен postgres на порту 5432 и создана база <i>product_test_db</i>
Тестовые данные находяться в файле <i>product_test_db.sql</i>. Параметры подключения к БД можно поменять в <i><strong>src/main/resources/application.properties</strong></i>.</p>

<h2>Описание методов API</h2>
<ul>
<li>GET /products - получить все продукты</li>
<li>POST /products - создать продукт(необходимо передать поля <i>name</i> и <i>amount</i> в теле запроса)</li>
<li>GET /products/{id} - получить продукт по id</li>
<li>DELETE /products/{id} - удалить продукт по id</li>
<li>PUT /products/{id} - обновить продукт по id (необходимо передать поля <i>name</i> и <i>amount</i> в теле запроса)</li>
<li>GET /products/amount_sum/{name} - получить сумму полей amount по имени</li>
</ul>