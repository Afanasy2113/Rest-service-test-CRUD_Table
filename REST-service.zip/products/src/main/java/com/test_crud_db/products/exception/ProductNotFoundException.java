package com.test_crud_db.products.exception;

public class ProductNotFoundException extends RuntimeException{
    public ProductNotFoundException(Long id){
        super("Could not find product " + id);
    }
}
