package com.test_crud_db.products.repository;

import com.test_crud_db.products.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findAll();

    @Query(value = "SELECT COALESCE(SUM(amount),0) FROM products WHERE name =:name", nativeQuery = true)
    Long getAmountSumByName(String name);
}
