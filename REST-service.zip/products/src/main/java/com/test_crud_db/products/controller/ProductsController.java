package com.test_crud_db.products.controller;

import com.test_crud_db.products.entity.Product;
import com.test_crud_db.products.exception.ProductNotFoundException;
import com.test_crud_db.products.repository.ProductRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductsController {
    private final ProductRepository productRepository;

    public ProductsController(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @GetMapping("/products")
    List<Product> all(){
        return productRepository.findAll();
    }

    @PostMapping("/products")
    Product newProduct(@RequestBody Product newProduct){
        return productRepository.save(newProduct);
    }

    @GetMapping("/products/{id}")
    Product one(@PathVariable Long id){
        return productRepository.findById(id).orElseThrow(()->new ProductNotFoundException(id));
    }

    @PutMapping("/products/{id}")
    Product updateProduct(@RequestBody Product updateProduct, @PathVariable Long id){
        return productRepository.findById(id)
                .map(product->{
                    product.setName(updateProduct.getName());
                    product.setAmount(updateProduct.getAmount());

                    productRepository.save(product);
                    return product;
                })
                .orElseThrow(()->new ProductNotFoundException(id));
    }

    @DeleteMapping("/products/{id}")
    void deleteProduct(@PathVariable Long id){
        productRepository.deleteById(id);
    }

    @GetMapping("/products/amount_sum/{name}")
    Long getSumByName(@PathVariable String name){
        return productRepository.getAmountSumByName(name);
    }

}
